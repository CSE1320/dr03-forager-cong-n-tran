import React from "react";
 

const Button = () => {
    return (
        <button className="border border-blue-500">
        button
        </button>
    );
};
export default Button; 